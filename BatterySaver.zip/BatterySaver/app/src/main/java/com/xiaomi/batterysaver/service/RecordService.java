package com.xiaomi.batterysaver.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.xiaomi.batterysaver.MainActivity;
import com.xiaomi.batterysaver.R;

import java.io.File;
import java.io.IOException;

public class RecordService extends Service {

    private MediaRecorder mediaRecorder;
    private static final String CHANNEL_ID = "ForegroundServiceChannel";
    private static final String TAG = "RecordService";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, buildNotification());
        initMediaRecorder();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaRecorder != null) {
            mediaRecorder.stop();
            mediaRecorder.release();
            mediaRecorder = null;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    private Notification buildNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Recording audio")
                .setContentIntent(pendingIntent)
                .setContentText("Audio is being recorded in the background")
                .setSmallIcon(R.drawable.icons8_xiaomi_240)
                .build();
    }

    @SuppressWarnings("deprecation")
    private void initMediaRecorder() {
        // Get the app's private directory
        File filesDirectory = getFilesDir();
        String fileName = "audio_record_" + System.currentTimeMillis() + ".3gp";
        File audioFile = new File(filesDirectory, fileName);
        String filePath = audioFile.getAbsolutePath();

        // Initialize MediaRecorder
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setOutputFile(filePath);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mediaRecorder.prepare();
            mediaRecorder.start(); // Start recording immediately after prepare
        } catch (IOException e) {
            Log.e(TAG, "Error preparing media recorder", e);
        }

        // Save the recorded audio file to MediaStore
        saveToMediaStore(filePath);
    }

    private void saveToMediaStore(String filePath) {
        // Get content resolver
        ContentResolver contentResolver = getContentResolver();

        // Set up content values for the audio file
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Audio.Media.DISPLAY_NAME, "audio_record_" + System.currentTimeMillis() + ".3gp");
        contentValues.put(MediaStore.Audio.Media.MIME_TYPE, "audio/3gpp");
        contentValues.put(MediaStore.Audio.Media.IS_PENDING, 1);

        // Insert audio file into MediaStore
        Uri audioUri = contentResolver.insert(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), contentValues);

        try {
            // Write the audio data into the file specified by the content resolver
            if (audioUri != null) {
                contentResolver.openOutputStream(audioUri).close();
                contentValues.clear();
                contentValues.put(MediaStore.Audio.Media.IS_PENDING, 0);
                contentResolver.update(audioUri, contentValues, null, null);
            }
        } catch (IOException e) {
            Log.e(TAG, "Error writing audio data to MediaStore", e);
        }
    }
}
